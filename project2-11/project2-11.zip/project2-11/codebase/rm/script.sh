make
rm *.tbl *.stat
rmtest_create_tables
rmtest 

