ixtest_01
ixtest_02
ixtest_03
ixtest_04
ixtest_05
ixtest_06
ixtest_07
ixtest_08
ixtest_09
ixtest_10
ixtest_12
ixtest_13
ixtest_14
ixtest_15
echo "Done with all tests and skipped test 11"
